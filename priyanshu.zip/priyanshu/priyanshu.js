// document.write("hello wold")

// age=20

// document.write(age,"<br>","age","<br>","rahul")
// alert("this is harmful webiste")
// a=prompt("enter your age ?")
// document.write(a)
// confirm("are your rahul ?")
// document.write("agenjghj")




// if(condition)
// {
//     statements
// }

// sdents=20

// if(students>=40)
// {
// document.write("students above than 20")
// }


// age=14

// if(age>=18){
//     document.write("eligible for vote")
// }


// staff=45
// if(staff>=35)
// {document.write("staff above than 30")}




// student = 20


// document.write(student)
// document.write("student")
// document.write('student')
// document.write(studet)
// document.write("studet")
// document.write("student",student)

// if(condition){
//     statement: 1
// }

// else{
//     statement: 2
// }

// question 1

// age=21

// if(age>=18){
//     document.write("age is greater than 18","<br>")
// }
// else{
//     document.write("thie value is less than 18")
// }

// question 2
// age=prompt("enter your value")
// document.write(age)

// if(age>=18){
//     document.write("eligible for vote")
// }
// else{
//     document.write("not eligible for vote")
// }


// question 3

// a=prompt("enter your value")

// b=prompt("enter your value")

// if(a>b){
//     document.write("a is greater than b")
// }
// else{
//     document.write("b is greater than a")
// }

// x=40
// y=34

// if(x>y){document.write("x is greater than y")
// }
// else{document.write("y is greater than x")
// }


// varibles
// datatypes

// operators 


//If-else

// Nested if-else 
//Switch
//Array
//Function
//DOM(Document object model)
//Exception Handling



// m = prompt("enter you age")
// // f=12
// if (m >= 18) {
//     document.write("18 is above ")
// }
// else {
//     document.write("18-is-not-")
// }

//age=prompt("enter your value")

// if(age>=18){
//     document.write("above than 18")
// }
// else{
//     document.write("less than 18")
// }

// a=prompt("enter your age")
// b=prompt("enter you mark")

// if(a+b>=100){
//     document.write("sum is 100")
// }
// else{
//     document.write("sum is not 100")

// }


// value1=prompt("enter your value")
// value2=prompt("enter your value")

// if(value1+value2>=100){
//     document.write("pass")
// }

// else{
//     document.write("fail")
// }

// bill=prompt("enter value")

// if(bill>=2000)
// {
//     discoount=bill*0.3
//     document.write("your discount value is",discoount,"<br>")
//     Real_bill=bill-discoount
//     document.write("your toltal bill is",Real_bill)
//     priyanshu=a*30/100

// }
// else{
//     document.write(bill)
// }

// percentage=prompt("enter your percentage")

// if(percentage>=90){
// document.write("the grade is A+")
// }
// else if(percentage>=70){

// }
// else if(a>=64){

// }


// else{

// }

// document.write("hellohjg")

// document.write("1,2,3,4,5,6")

// if(condition){

// }
// ++
// --

//a=87

// for(variable;condition;increment/decrement){


//     

// 

// 

// data=["rahul","rohan","ram"]
// document.write(data[0]) 

// a = [65,76,87]
// total=0
// for (i = 0; i <=a.length; ++i) 

// {
//      total = total + a[i]
// }
// document.write("your total is", total, "<br>")
















